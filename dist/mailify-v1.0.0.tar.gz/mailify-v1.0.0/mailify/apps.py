from django.apps import AppConfig


class MailifyConfig(AppConfig):
    name = 'mailify'
