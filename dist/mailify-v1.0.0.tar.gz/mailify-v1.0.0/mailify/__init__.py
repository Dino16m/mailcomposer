from mailify.apps import MailifyConfig
from mailify.management.commands import Command
default_app_config = 'mailify.apps.MailifyConfig'

